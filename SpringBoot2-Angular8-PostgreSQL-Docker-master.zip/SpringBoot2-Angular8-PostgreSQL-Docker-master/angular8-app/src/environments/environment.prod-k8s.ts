export const environment = {
  production: true,
  apiUrl: 'http://demo-app.demo.apside-top.fr'
};
