export const environment = {
  production: true,
  apiUrl: 'http://api.demo-app.127.0.0.1.nip.io:8080'
};
