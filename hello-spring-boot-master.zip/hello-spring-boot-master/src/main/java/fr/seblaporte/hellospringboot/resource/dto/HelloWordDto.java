package fr.seblaporte.hellospringboot.resource.dto;

public class HelloWordDto {

    private String message;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
