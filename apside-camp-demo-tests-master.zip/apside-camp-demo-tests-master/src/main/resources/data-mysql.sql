INSERT INTO address (city, number, postcode, street) VALUES ('Orléans', '2', '45000', 'avenue de Paris');
INSERT INTO address (city, number, postcode, street) VALUES ('Saint-Pierre-des-Corps', '2', '37700', 'place de la gare');
INSERT INTO user (email, name, surename, address_id) VALUES ('laporte.0209@apside-groupe.com', 'Laporte', 'Sébastien', 1);
INSERT INTO user (email, name, surename, address_id) VALUES ('chantreau.0138@apside-groupe.com', 'Chantreau', 'Nicolas', 1);
INSERT INTO user (email, name, surename, address_id) VALUES ('araoune@apside.fr', 'Araoune', 'Mélissa', 2);