# Formation Docker

> Slides, demonstration et TP sur l'utilisation de Docker et Docker-compose

## part1

Présentation de Docker et démonstration autour d'un simple serveur Web

## part2

Présentation de Docker-compose et démonstration avec le déploiement d'un Wordpress multi-environnement

## TP

TP en 2 parties :
- Dans le premier, l'objectif est de prendre en main Docker et Docker-compose en déployant un site web statique au moyen d'un serveur Nginx
- Pour la seconde partie, il est proposé de déployer une application Node.JS avec une base de données MySQL.