# Image Docker Jenkins

Projet Docker pour la construction d'une image Jenkins pré-configurée.

- Le répertoire groovy contient des fichiers de configuration pour Jenkins
- Le fichier `plugins.txt` contient la liste des plugins installés au build de l'image
